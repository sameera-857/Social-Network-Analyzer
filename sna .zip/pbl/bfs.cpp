#include <iostream>
#include <vector>
#include <queue>
#include <list> 
using namespace std;

class Graph {
    int V; 
    vector<list<int>> adj; 

public:
    Graph(int v) : V(v), adj(v) {}

    void addEdge(int u, int v) {
        adj[u].push_back(v); 
        adj[v].push_back(u); 
    }

    void BFS(int startNode) {
        vector<bool> visited(V, false);
       
        queue<int> q;

        
        visited[startNode] = true;
        q.push(startNode);

        while (!q.empty()) {
            
            int currNode = q.front();
            q.pop();
            cout << currNode << " ";

            
            for (int neighbor : adj[currNode]) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    q.push(neighbor);
                }
            }
        }
        cout << endl;
    }
};


int main() {
    
    Graph g(5);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(1, 4);
    g.addEdge(2, 0); 
    g.addEdge(2, 3);
    g.addEdge(3, 1); 
    g.addEdge(4, 1); 

    
    g.BFS(0);

    return 0;
}


